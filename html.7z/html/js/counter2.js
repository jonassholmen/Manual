
            let addBtn = document.querySelector('#legg');
            let subBtn = document.querySelector('#trekk');
            let qty = document.querySelector('#resultat2');
            
            addBtn.addEventListener('click',()=>{
                qty.value = parseInt(qty.value) + 1;
            });
        
            subBtn.addEventListener('click',()=>{
                if (qty.value <= 0) {
                    qty.value = 0;
                }
                else{
                    qty.value = parseInt(qty.value) - 1;
                }
            });

            let addBtn2 = document.querySelector('#add');
            let subBtn2 = document.querySelector('#sub');
            let qty2 = document.querySelector('#resultat1');
            
            addBtn2.addEventListener('click',()=>{
                qty2.value = parseInt(qty2.value) + 1;
            });
    
            subBtn2.addEventListener('click',()=>{
                if (qty2.value <= 0) {
                    qty2.value = 0;
                }
                else{
                    qty2.value = parseInt(qty2.value) - 1;
                }
            });

            function test(){
                let value1 = document.getElementById("resultat1").value;
                let value2 = document.getElementById("resultat2").value;
            
                var xhr = new XMLHttpRequest();
                
                xhr.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                        alert("Order complete, delivery in progress.");
                    }
                };
                
                xhr.open("POST", "http://192.168.1.158:5001/post" , true);
                xhr.setRequestHeader("Accept", "application/json");
                xhr.setRequestHeader('Access-Control-Allow-Origin', '*');
                xhr.setRequestHeader('Content-Type', 'application/json');
                xhr.send(JSON.stringify({
                    "verdi1": value1,
                    "verdi2": value2
                }));
            
            }



            
