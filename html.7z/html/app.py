from flask import Flask, request
from flask_cors import cross_origin

app = Flask(__name__)


@app.route('/post', methods=['POST'])
# Dette er config slik at du tillater at en uidentifisert aktør bruker endepunktet
@cross_origin(origin='*',headers=['Content- Type','Authorization'])
def hello_world():
    # Her henter du ut body'en
    content = request.json
    # VERDI 1
    print(content["verdi1"])
    # VERDI 2
    print(content["verdi2"])

    # returner bare noe for at den ikke krasjer
    return "ok"


if __name__ == '__main__':
    app.run()